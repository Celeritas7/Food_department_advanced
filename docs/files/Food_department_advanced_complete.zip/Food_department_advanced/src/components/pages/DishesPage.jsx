/**
 * DishesPage.jsx — Dishes with emoji, country/type multi-filters
 */
import { useState, useMemo } from 'react';
import { DishIcon, PlusIcon, EditIcon, DelIcon } from '../ui/Icons';
import { PriorityBadge } from '../ui/Badges';
import FilterBar from '../ui/FilterBar';
import { getDishTypeEmoji, getCountryFlag } from '../../config/emoji.js';

export default function DishesPage({ dishes, onAdd, onEdit, onCook, onDelete }) {
  const [statusFilter, setStatusFilter] = useState('active');
  const [countryFilter, setCountryFilter] = useState([]);
  const [typeFilter, setTypeFilter] = useState([]);

  const toggleFilter = (arr, setArr) => (val) => {
    setArr(prev => prev.includes(val) ? prev.filter(v => v !== val) : [...prev, val]);
  };

  // Dynamic filter options from data
  const countryOptions = useMemo(() => {
    const countries = [...new Set(dishes.map(d => d.country).filter(Boolean))].sort();
    return countries.map(c => ({ value: c, label: c, emoji: getCountryFlag(c) }));
  }, [dishes]);

  const typeOptions = useMemo(() => {
    const types = [...new Set(dishes.map(d => d.dish_type).filter(Boolean))].sort();
    return types.map(t => ({ value: t, label: t, emoji: getDishTypeEmoji(t) }));
  }, [dishes]);

  const filtered = useMemo(() => {
    let list = dishes;
    // Status filter
    if (statusFilter === 'active') list = list.filter(d => d.status !== 'Cooked');
    else if (statusFilter === 'ready') list = list.filter(d => d.status !== 'Cooked' && d._availability?.canCook);
    else if (statusFilter === 'cooked') list = list.filter(d => d.status === 'Cooked');
    // Country
    if (countryFilter.length) list = list.filter(d => countryFilter.includes(d.country));
    // Type
    if (typeFilter.length) list = list.filter(d => typeFilter.includes(d.dish_type));

    return list.sort((a, b) => {
      if (a.status === 'Cooked' && b.status !== 'Cooked') return 1;
      if (a.status !== 'Cooked' && b.status === 'Cooked') return -1;
      return a.priority - b.priority;
    });
  }, [dishes, statusFilter, countryFilter, typeFilter]);

  return (
    <div className="min-h-screen bg-cream pb-24">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-terracotta/10 flex items-center justify-center text-terracotta"><DishIcon /></div>
            <div>
              <h1 className="font-semibold text-xl">🍽️ Dishes</h1>
              <p className="text-sm text-warm-gray">Plan & cook · {filtered.length} shown</p>
            </div>
          </div>
          <button onClick={onAdd} className="p-2.5 rounded-lg bg-terracotta text-white"><PlusIcon /></button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-4">
        {/* Status tabs */}
        <div className="flex gap-2 mb-4">
          {['active', 'ready', 'all', 'cooked'].map(f => (
            <button key={f} onClick={() => setStatusFilter(f)} className={`px-3 py-1.5 rounded-lg text-sm font-medium ${statusFilter === f ? 'bg-terracotta text-white' : 'bg-white text-warm-gray border'}`}>
              {f[0].toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {/* Country & Type filters */}
        {countryOptions.length > 0 && (
          <FilterBar label="Country" filters={countryOptions} active={countryFilter} onToggle={toggleFilter(countryFilter, setCountryFilter)} />
        )}
        {typeOptions.length > 0 && (
          <FilterBar label="Type" filters={typeOptions} active={typeFilter} onToggle={toggleFilter(typeFilter, setTypeFilter)} />
        )}

        {(countryFilter.length > 0 || typeFilter.length > 0) && (
          <button onClick={() => { setCountryFilter([]); setTypeFilter([]); }} className="text-xs text-terracotta font-medium mb-4 hover:underline">✕ Clear filters</button>
        )}

        {/* Dish cards */}
        {!filtered.length ? (
          <p className="text-center py-16 text-warm-gray">{dishes.length ? 'No matches' : 'No dishes yet'}</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(d => {
              const isActive = d.status !== 'Cooked';
              const av = d._availability || {};
              return (
                <div key={d.id} className={`bg-white rounded-xl border p-4 fade ${!isActive && 'opacity-60'}`}>
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-semibold">
                        {d.dish_type ? getDishTypeEmoji(d.dish_type) : '🍽️'} {d.name}
                      </h3>
                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${d.status === 'Cooked' ? 'bg-sage/20 text-sage' : 'bg-blue-100 text-blue-700'}`}>{d.status}</span>
                        <PriorityBadge priority={d.priority} />
                        {d.country && <span className="text-xs px-2 py-0.5 rounded-full bg-light-gray/30">{getCountryFlag(d.country)} {d.country}</span>}
                        {d.dish_type && <span className="text-xs px-2 py-0.5 rounded-full bg-light-gray/30">{getDishTypeEmoji(d.dish_type)} {d.dish_type}</span>}
                      </div>
                    </div>
                  </div>
                  {isActive && (
                    <p className="text-xs mt-2">
                      {av.unlinked ? <span className="text-amber-600">⚠️ Unlinked</span>
                        : av.canCook ? <span className="text-sage">✓ Ready</span>
                        : <span className="text-tomato">Missing: {[...av.missing?.map(m => m.name) || [], ...av.missingInts?.map(m => m.name) || []].join(', ')}</span>}
                    </p>
                  )}
                  <div className="flex gap-1 mt-3 pt-3 border-t">
                    {isActive && (
                      <button onClick={() => onCook(d)} disabled={!av.canCook} className={`flex-1 py-1.5 rounded text-sm ${av.canCook ? 'text-sage hover:bg-sage/10' : 'text-light-gray cursor-not-allowed'}`}>Cook</button>
                    )}
                    <button onClick={() => onEdit(d)} className="p-1.5 rounded text-warm-gray hover:bg-light-gray/20"><EditIcon /></button>
                    <button onClick={() => onDelete(d)} className="p-1.5 rounded text-warm-gray hover:text-tomato"><DelIcon /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
